 
 import React from 'react';

 class GitHubSearch extends React.Component {
       constructor(props){ 
         
         super(props); 
          this.state = { 
            listUser:[],
           username: '',
           userrepo: '',
          };
       }

       getUser(username) {
         
          return fetch(`https://api.github.com/users/${username}`)
          .then(response => response.json())
          .then(response => {
            return response;
           })
      }

       getUserRepo(userrepo,username) {
         return fetch(`https://api.github.com/users/${username}/repos`)
         .then(response => response.json())
         .then(response => {
          return response;
        })
      }

       async handleSubmit(e) {
           e.preventDefault();
           let user = await this.getUser(this.refs.username.value);
           this.setState({ avatar_url: user.avatar_url,
           username: user.login,
           followers: user.followers,
           following: user.following,
            url: user.url,
       });

   let repo = await this.getUserRepo(this.refs.username.value);
        this.setState({ name: repo.name,
        description: repo.description,
        git_url: repo.git_url,
        stargazers_count: repo.stargazers_count,
        forks_count: repo.forks_count,
        open_issues_count: repo.open_issues_count,
        size: repo.size,

     })

  }

     render() {
       let user;
       
       if(this.state.username) {
         
          user = 
          <div className="resultDiv">
           
            <img src={this.state.avatar_url}/>
              
            <p className="userInfo">
            <i>  Username: {this.state.username} </i> 
            </p> 
            

            <p className="follower">
            <i>Followers: {this.state.followers} </i> 
            </p>

            <p className="following">
             <i>  Following {this.state.following} users</i> 
            </p>

          </div>
      }

      let repo;
        if(this.state.userrepo) {
           repo =
             <div className="repoResults">
                <p>
                  {this.state.name}
               </p>
             </div>
         }

           return (
              <div className="GitHubSearchDiv"> 
              <div class="parent-card">
                <header className="Search-div">
                  <h1> User Search </h1>
                </header>

                <form onSubmit={e => this.handleSubmit(e)}>
                   <input ref='username' type='text' id="search-ip" placeholder='Enter username' />                
               </form>

               <p className="Search-intro-Div">
                  {user}                  
               </p>        
               <p>
                 {repo}
               </p>
      </div>
      </div>
   );
 }
}



export default GitHubSearch;